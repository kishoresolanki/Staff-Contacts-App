package com.example.vvce_staff;

public class Departments {
    String dName;

    public Departments (String Name){
        this.dName=Name;
    }

    public String getDepartmentName(){
        return  dName;
    }

}
